from .blacklist import blacklisted_users
LIST = {}
DEVLIST = [5571722913, 6669024587]
