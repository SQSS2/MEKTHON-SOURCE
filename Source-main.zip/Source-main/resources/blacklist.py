blacklisted_users = [ 
  1234567890,
]
